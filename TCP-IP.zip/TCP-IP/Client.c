#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <string.h>
#include <time.h>  

#define TAILLE_TAB (1 << 16)  // Taille des tableau locaux
#define NB_APPELS_PAR_PROCESSUS 1000000000  // Nombre d'appels par processus
#define NB_PROCESSUS 5  // Nombre de processus
#define PORT_SERVEUR 8080  // Port du serveur
#define IP_SERVEUR "127.0.0.1" // IP du serveur




// Fonction pour générer un nombre aléatoire
unsigned int generer_nb_alea() {
    return rand() % TAILLE_TAB;  
}


// Fonction exécutée par chaque processus
void travail_processus(int id_processus, int sock_fd) {
    
    // Initialisation de la graine pour ce processus
    // Pour obtenir des séquences différentes, il est important d'initialiser la graine avec une valeur qui change.
    srand(time(NULL) ^ getpid());

    long *resultats_locaux = calloc(TAILLE_TAB, sizeof(long));
    if (resultats_locaux == NULL) {
        perror("Échec de calloc");
        exit(EXIT_FAILURE);
    }

    // Génération des nombres aléatoires
    printf("Processus %d : Début de la génération des nombres aléatoires\n", id_processus);
    for (int i = 0; i < NB_APPELS_PAR_PROCESSUS; i++) {
        unsigned int numero_aleatoire = generer_nb_alea();
        resultats_locaux[numero_aleatoire]++;
    }
    printf("Processus %d : Génération des nombres aléatoires terminée\n", id_processus);

    // Envoi des données au serveur
    printf("Processus %d : Début de l'envoi des données au serveur\n", id_processus);
    size_t total_envoye = 0;
    while (total_envoye < TAILLE_TAB * sizeof(long)) {
        ssize_t envoye = send(sock_fd, ((char *)resultats_locaux) + total_envoye,
                              TAILLE_TAB * sizeof(long) - total_envoye, 0);
        if (envoye < 0) {
            perror("Échec de send");
            free(resultats_locaux);
            close(sock_fd);
            exit(EXIT_FAILURE);
        }
        total_envoye += envoye;
    }
    printf("Processus %d : Données envoyées au serveur\n", id_processus);

    // Attente de la confirmation du serveur
    printf("Processus %d : Attente de la confirmation du serveur\n", id_processus);
    char buffer[2];
    if (read(sock_fd, buffer, 2) < 0) {
        perror("Échec de la lecture de la confirmation");
    } else {
        // Afficher le message de confirmation
        printf("Processus %d : Le serveur a bien reçu les données\n", id_processus);
    }

    free(resultats_locaux);
    close(sock_fd);
    printf("Processus %d terminé\n", id_processus);
    exit(EXIT_SUCCESS);
}





int main() {
    // Tableau pour stocker les identifiants des processus enfants
    pid_t pids[NB_PROCESSUS];

    // Boucle pour créer NB_PROCESSUS processus enfants
    for (int i = 0; i < NB_PROCESSUS; i++) {
        
        // Création d'un processus enfant avec fork()
        pids[i] = fork();

        // Gestion des erreurs de fork()
        if (pids[i] < 0) {
            perror("Échec de fork");  // Affiche un message d'erreur si fork échoue
            exit(EXIT_FAILURE);       // Quitte le programme en cas d'échec
        } 

        else if (pids[i] == 0) {

            // Création d'un socket pour la communication avec le serveur
            int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
            if (sock_fd < 0) {
                perror("Échec de la création du socket");  
                exit(EXIT_FAILURE);                       
            }

            // Configuration de l'adresse du serveur
            struct sockaddr_in adresse_serveur = {0};
            adresse_serveur.sin_family = AF_INET;          // Famille d'adresses (IPv4)
            adresse_serveur.sin_port = htons(PORT_SERVEUR); // Port du serveur (converti en format réseau)
            
            // Conversion de l'adresse IP du serveur en format binaire
            if (inet_pton(AF_INET, IP_SERVEUR, &adresse_serveur.sin_addr) <= 0) {
                perror("Échec de inet_pton");  // Gestion des erreurs de conversion d'adresse
                close(sock_fd);                // Fermeture du socket en cas d'échec
                exit(EXIT_FAILURE);            // Quitte en cas d'échec
            }

            // Connexion au serveur
            if (connect(sock_fd, (struct sockaddr *)&adresse_serveur, sizeof(adresse_serveur)) < 0) {
                perror("Échec de la connexion");  // Gestion des erreurs de connexion
                close(sock_fd);                  // Fermeture du socket en cas d'échec
                exit(EXIT_FAILURE);              // Quitte en cas d'échec
            }

            // Envoi du nombre de processus au serveur
            int nb_processus = NB_PROCESSUS;
            if (write(sock_fd, &nb_processus, sizeof(int)) < 0) {
                perror("Échec de l'envoi du nombre de processus");  // Gestion des erreurs d'envoi
                close(sock_fd);                                    // Fermeture du socket en cas d'échec
                exit(EXIT_FAILURE);                                // Quitte en cas d'échec
            }

            // Appel de la fonction travail_processus pour exécuter le travail du client
            travail_processus(i, sock_fd);
        }
    }

    // Attente de la fin de tous les processus enfants
    for (int i = 0; i < NB_PROCESSUS; i++) {
        wait(NULL);  
    }

  
    printf("Tous les processus ont terminé et envoyé leurs données au serveur.\n");
    
    
    return 0;
}