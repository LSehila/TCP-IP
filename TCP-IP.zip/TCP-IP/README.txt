Avant de compiler le code veuillez suivre ces instructions SVP : 

  - Si vous n'avez pas Gnuplot d'installé ,  veuillez taper la commande suivante dans le terminal : 
    - sudo apt update
    - sudo apt install gnuplot

Gnuplot sert à générer un graphe 


 -  Pour exécuter sur deux machines vous pouvez direct modifier l'IP du serveur dans le code Client .

Modifier l'adresse IP du serveur : 
- L'adresse IP du serveur est définie dans le fichier client.c par la macro IP_SERVEUR.


Pour compiler :  
  - Serveur : 
	gcc serveur.c -o serveur -lpthread -lrt -lm

  - Client : 
	gcc client.c -o client -lrt


Fichiers générés : 

data.txt : Contient les données brutes utilisées pour générer le graphe.

graph.png : Un graphe montrant la distribution des nombres aléatoires.