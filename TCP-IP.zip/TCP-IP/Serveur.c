#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <string.h>
#include <sys/time.h>
#include <math.h>

#define TAILLE_TAB (1 << 16)  // Taille du tableau partagé
#define PORT_SERVEUR 8080  // Port du serveur
#define NB_MAX_CLIENTS 10  // Nombre maximum de clients simultanés
#define NB_CLIENTS 1 // Nombre de clients


long *tableau_general = NULL;  // Tableau Final
sem_t *mutex_serveur = NULL;   // Sémaphore pour synchroniser l'accès aux Cases du tableau
int total_processus_termines = 0;



/*
 Cette fonction Calcule l'équilibrage du tableau partagé.
 Retourne un coefficient de variation.
 */

double calculer_equilibrage(long *tableau, int taille) {
    if (tableau == NULL) {
        fprintf(stderr, "Erreur : tableau est NULL dans calculer_equilibrage\n");
        exit(EXIT_FAILURE);
    }

    long somme = 0;
    long somme_carres = 0;

    // Calcul de la somme et de la somme des carrés
    for (int i = 0; i < taille; i++) {
        somme += tableau[i];
        somme_carres += tableau[i] * tableau[i];
    }

    // Calcul de la moyenne
    double moyenne = (double)somme / taille;

    // Calcul de la variance et de l'écart-type
    double variance = ((double)somme_carres / taille) - (moyenne * moyenne);
    double ecart_type = sqrt(variance);

    // Calcul du coefficient de variation
    double coefficient_variation = ecart_type / moyenne;
    return coefficient_variation;
}



/*
Cette fonction génère un graphe à partir des données collectées et quitte le programme.
Elle exporte les données dans un fichier texte, utilise gnuplot pour générer un graphe,
calcule la moyenne des fréquences et libère les ressources partagées.
 */
void genererGraphe(void) {
    if (tableau_general == NULL) {
        fprintf(stderr, "Erreur : tableau_general est NULL dans genererGraphe\n");
        return;
    }

    FILE *fichier_donnees = fopen("data.txt", "w");
    if (!fichier_donnees) {
        perror("Échec de la création du fichier de données");
        return;
    }

    // Écriture des données dans le fichier pour gnuplot
    for (int i = 0; i < TAILLE_TAB; i++) {
        fprintf(fichier_donnees, "%d %ld\n", i, tableau_general[i]);
    }
    fclose(fichier_donnees);

    // Exécution de gnuplot pour générer un graphe PNG
    FILE *gnuplot = popen("gnuplot", "w");
    if (!gnuplot) {
        perror("Échec du lancement de gnuplot");
        return;
    }

    fprintf(gnuplot, "set terminal png size 1920,1080\n");
    fprintf(gnuplot, "set output 'graph.png'\n");
    fprintf(gnuplot, "set title 'Distribution des nombres aléatoires'\n");
    fprintf(gnuplot, "set xlabel 'Index'\n");
    fprintf(gnuplot, "set ylabel 'Fréquence'\n");
    fprintf(gnuplot, "plot 'data.txt' with lines title 'Fréquence'\n");

    fflush(gnuplot);
    int ret = pclose(gnuplot);

    if (ret != 0) {
        printf("Erreur de gnuplot : %d\n", ret);
        return;
    }

    // Vérification si le graphe a été créé correctement
    if (access("graph.png", F_OK) == 0) {
        printf("Graphe créé avec succès sous le nom 'graph.png'\n");
        printf("Tous les résultats sont dans le fichier 'data.txt'\n");
    } else {
        perror("Échec de la génération du graphe");
    }

    // Calcul de la moyenne des fréquences
    long somme_frequences = 0;
    for (int i = 0; i < TAILLE_TAB; i++) {
        somme_frequences += tableau_general[i];
    }
    double moyenne_frequences = (double)somme_frequences / TAILLE_TAB;
    printf("Moyenne des fréquences : %.2f\n", moyenne_frequences);

    // Calcul de l'équilibrage des données
    double coefficient_variation = calculer_equilibrage(tableau_general, TAILLE_TAB);
    printf("Coefficient de variation (équilibrage) : %.4f\n", coefficient_variation);

    // Calcul du min et du max des fréquences
    long min_frequence = tableau_general[0];
    long max_frequence = tableau_general[0];
    for (int i = 1; i < TAILLE_TAB; i++) {
        if (tableau_general[i] < min_frequence) {
            min_frequence = tableau_general[i];
        }
        if (tableau_general[i] > max_frequence) {
            max_frequence = tableau_general[i];
        }
    }
    printf("Fréquence minimale : %ld\n", min_frequence);
    printf("Fréquence maximale : %ld\n", max_frequence);

    // Calcul du seuil
    long seuil = somme_frequences / TAILLE_TAB;  // Nombre total d'appels / taille du tableau
    printf("Seuil d'occurrences attendu : %ld\n", seuil);

    // Calcul du pourcentage de valeurs supérieures ou égales au seuil
    int compteur = 0;
    for (int i = 0; i < TAILLE_TAB; i++) {
        if (tableau_general[i] >= seuil) {
            compteur++;
        }
    }
    double pourcentage = (double)compteur / TAILLE_TAB * 100;
    printf("Pourcentage de valeurs >= seuil : %.2f%%\n", pourcentage);

    printf("Merci pour votre patience. Le programme va maintenant s'arrêter.\n");

    // Fermeture des ressources partagées
    if (mutex_serveur != NULL) {
        sem_close(mutex_serveur);
        sem_unlink("mutex_serveur");
    }
    if (tableau_general != NULL) {
        munmap(tableau_general, TAILLE_TAB * sizeof(long));
        shm_unlink("comptes_serveur");
    }
    exit(0);
}





/*
Cette fonction Gère la communication avec un client connecté. Cette fonction reçoit un tableau de fréquences du client,
met à jour les comptes partagés et ferme la connexion.
 */
void *gerer_client(void *arg) {
    int sock_fd = *(int *)arg;
    free(arg);

    // Recevoir le nombre de processus du client
    int nb_processus_client;
    if (read(sock_fd, &nb_processus_client, sizeof(int)) < 0) {
        perror("Échec de la lecture du nombre de processus");
        close(sock_fd);
        pthread_exit(NULL);
    }

    long *comptes_client = calloc(TAILLE_TAB, sizeof(long));
    if (comptes_client == NULL) {
        perror("Échec de calloc");
        close(sock_fd);
        pthread_exit(NULL);
    }

    // Réception des données du client
    size_t total_recu = 0;
    while (total_recu < TAILLE_TAB * sizeof(long)) {
        ssize_t octets_lus = read(sock_fd, ((char *)comptes_client) + total_recu,
                                  TAILLE_TAB * sizeof(long) - total_recu);
        if (octets_lus < 0) {
            perror("Échec de read");
            free(comptes_client);
            close(sock_fd);
            pthread_exit(NULL);
        } else if (octets_lus == 0) {
            printf("Client déconnecté prématurément (socket fd: %d)\n", sock_fd);
            free(comptes_client);
            close(sock_fd);
            pthread_exit(NULL);
        }
        total_recu += octets_lus;
    }
    printf("Données reçues du client (socket fd: %d)\n", sock_fd);

    // Envoyer une confirmation au client
    if (write(sock_fd, "OK", 2) < 0) {
        perror("Échec de l'envoi de la confirmation");
    }

    // Mise à jour des comptes partagés
    if (mutex_serveur == NULL || tableau_general == NULL) {
        fprintf(stderr, "Erreur : mutex_serveur ou tableau_general est NULL\n");
        free(comptes_client);
        close(sock_fd);
        pthread_exit(NULL);
    }

    sem_wait(mutex_serveur);
    for (int i = 0; i < TAILLE_TAB; i++) {
        tableau_general[i] += comptes_client[i];
    }

    printf("Après mise à jour du tableau final :\n");
    for (int i = 0; i < 10; i++) {
        printf("Index %d: %ld\n", i, tableau_general[i]);
    }

    // Incrémenter le compteur de processus terminés
    total_processus_termines++;
    sem_post(mutex_serveur);

    free(comptes_client);
    close(sock_fd);

    // Si tous les processus ont terminé, générer le graphe
    if (total_processus_termines >= NB_CLIENTS * nb_processus_client) {
        genererGraphe();
    }

    pthread_exit(NULL);
}






/*
Notre fonction main Initialise la mémoire partagée, le sémaphore, et le socket. 
Écoute les connexions des clients et les traite en parallèle via des threads.
*/

int main() {
    // Mesure du temps d'exécution
    struct timeval start_time, end_time;
    gettimeofday(&start_time, NULL);

    // Configuration de la mémoire partagée
    int shm_fd = shm_open("comptes_serveur", O_CREAT | O_RDWR, 0666);
    if (shm_fd < 0) {
        perror("Échec de shm_open");
        exit(EXIT_FAILURE);
    }
    if (ftruncate(shm_fd, TAILLE_TAB * sizeof(long)) < 0) {
        perror("Échec de ftruncate");
        close(shm_fd);
        exit(EXIT_FAILURE);
    }
    tableau_general = mmap(NULL, TAILLE_TAB * sizeof(long), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (tableau_general == MAP_FAILED) {
        perror("Échec de mmap");
        close(shm_fd);
        exit(EXIT_FAILURE);
    }
    memset(tableau_general, 0, TAILLE_TAB * sizeof(long));  // Initialisation à zéro

    // Log de l'initialisation
    printf("Initialisation du tableau final :\n");
    for (int i = 0; i < 10; i++) {
        printf("Index %d: %ld\n", i, tableau_general[i]);
    }

    // Création du sémaphore
    mutex_serveur = sem_open("mutex_serveur", O_CREAT, 0644, 1);
    if (mutex_serveur == SEM_FAILED) {
        perror("Échec de sem_open");
        munmap(tableau_general, TAILLE_TAB * sizeof(long));
        close(shm_fd);
        exit(EXIT_FAILURE);
    }

    // Création et configuration du socket
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd < 0) {
        perror("Échec de la création du socket");
        sem_close(mutex_serveur);
        munmap(tableau_general, TAILLE_TAB * sizeof(long));
        close(shm_fd);
        exit(EXIT_FAILURE);
    }

    // Configuration de l'adresse du serveur
struct sockaddr_in adresse_serveur = {0};  // Initialisation de la structure d'adresse du serveur
adresse_serveur.sin_family = AF_INET;      // Famille d'adresses (IPv4)
adresse_serveur.sin_port = htons(PORT_SERVEUR);  // Port du serveur (converti en format réseau)
adresse_serveur.sin_addr.s_addr = INADDR_ANY;  // Accepte les connexions sur toutes les interfaces réseau

// Liaison du socket à l'adresse du serveur
if (bind(sock_fd, (struct sockaddr *)&adresse_serveur, sizeof(adresse_serveur)) < 0) {
    perror("Échec de bind");  
    close(sock_fd);           // Fermeture du socket
    sem_close(mutex_serveur); // Fermeture du sémaphore
    munmap(tableau_general, TAILLE_TAB * sizeof(long));  // Libération de la mémoire partagée
    close(shm_fd);            // Fermeture du descripteur de fichier de la mémoire partagée
    exit(EXIT_FAILURE);       // Quitte le programme en cas d'échec
}

// Mise en écoute du socket pour accepter les connexions entrantes
if (listen(sock_fd, NB_MAX_CLIENTS) < 0) {
    perror("Échec de listen");  
    close(sock_fd);             
    sem_close(mutex_serveur);   
    munmap(tableau_general, TAILLE_TAB * sizeof(long)); 
    close(shm_fd);              
    exit(EXIT_FAILURE);      
}

printf("Serveur en écoute sur le port %d\n", PORT_SERVEUR);

// Boucle principale du serveur pour accepter les connexions clients
while (1) {

    // Allocation dynamique de mémoire pour stocker le descripteur de socket du client
    int *client_sock = malloc(sizeof(int));
    if (client_sock == NULL) {
        perror("Échec de malloc");  // Affiche un message d'erreur si l'allocation échoue
        continue;                   // Continue la boucle sans interrompre le serveur
    }

    // Acceptation d'une connexion client
    *client_sock = accept(sock_fd, NULL, NULL);
    if (*client_sock < 0) {
        perror("Échec de accept");  // Affiche un message d'erreur si l'acceptation échoue
        free(client_sock);          // Libération de la mémoire allouée pour le socket client
        continue;                   // Continue la boucle sans interrompre le serveur
    }

    printf("Client connecté (socket fd: %d)\n", *client_sock);


    // Création d'un thread pour gérer la connexion client
    pthread_t thread;
    if (pthread_create(&thread, NULL, gerer_client, client_sock) != 0) {
        perror("Échec de pthread_create");  // Affiche un message d'erreur si la création du thread échoue
        close(*client_sock);                
        free(client_sock);                  
    } else {
        pthread_detach(thread);  // Détachement du thread pour qu'il se libère automatiquement à la fin
    }
}

return 0;
}